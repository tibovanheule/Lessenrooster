package timetable.db;

import java.sql.Connection;

public interface DbConnect {
    Connection connect();
}
